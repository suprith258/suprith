import * as S from './style';

const Loader = () => (
  <S.Container>
    <div />
    <div />
    <div />
    <div />
  </S.Container>
);

export default Loader;
